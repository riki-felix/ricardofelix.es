/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************!*\
  !*** ./src/js/bundle.js ***!
  \**************************/
var mainNav = document.getElementById('mobilePanel');
var pagebody = document.getElementsByTagName('body')[0];
var navBarToggle = document.getElementById('menuToggle');
navBarToggle.addEventListener('click', function () {
  mainNav.classList.toggle('open');
  pagebody.classList.toggle('menu-is-open');
});
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsSUFBSUEsT0FBTyxHQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FBZDtBQUNBLElBQUlDLFFBQVEsR0FBR0YsUUFBUSxDQUFDRyxvQkFBVCxDQUE4QixNQUE5QixFQUFzQyxDQUF0QyxDQUFmO0FBQ0EsSUFBSUMsWUFBWSxHQUFHSixRQUFRLENBQUNDLGNBQVQsQ0FBd0IsWUFBeEIsQ0FBbkI7QUFDQUcsWUFBWSxDQUFDQyxnQkFBYixDQUE4QixPQUE5QixFQUF1QyxZQUFZO0VBQ2xETixPQUFPLENBQUNPLFNBQVIsQ0FBa0JDLE1BQWxCLENBQXlCLE1BQXpCO0VBQ0FMLFFBQVEsQ0FBQ0ksU0FBVCxDQUFtQkMsTUFBbkIsQ0FBMEIsY0FBMUI7QUFDQSxDQUhELEUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9QYXJlbnRlc2kvLi9zcmMvanMvYnVuZGxlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImxldCBtYWluTmF2ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21vYmlsZVBhbmVsJyk7XG5sZXQgcGFnZWJvZHkgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgnYm9keScpWzBdO1xubGV0IG5hdkJhclRvZ2dsZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtZW51VG9nZ2xlJyk7XG5uYXZCYXJUb2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbiAoKSB7XG5cdG1haW5OYXYuY2xhc3NMaXN0LnRvZ2dsZSgnb3BlbicpO1xuXHRwYWdlYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdtZW51LWlzLW9wZW4nKTtcbn0pOyJdLCJuYW1lcyI6WyJtYWluTmF2IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInBhZ2Vib2R5IiwiZ2V0RWxlbWVudHNCeVRhZ05hbWUiLCJuYXZCYXJUb2dnbGUiLCJhZGRFdmVudExpc3RlbmVyIiwiY2xhc3NMaXN0IiwidG9nZ2xlIl0sInNvdXJjZVJvb3QiOiIifQ==