/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************!*\
  !*** ./src/js/bundle.js ***!
  \**************************/
var mainNav = document.getElementById('mobilePanel');
var pagebody = document.getElementsByTagName('body')[0];
var navBarToggle = document.getElementById('menuToggle');
navBarToggle.addEventListener('click', function () {
  mainNav.classList.toggle('open');
  pagebody.classList.toggle('menu-is-open');
});
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsSUFBSUEsT0FBTyxHQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FBZDtBQUNBLElBQUlDLFFBQVEsR0FBR0YsUUFBUSxDQUFDRyxvQkFBVCxDQUE4QixNQUE5QixFQUFzQyxDQUF0QyxDQUFmO0FBQ0EsSUFBSUMsWUFBWSxHQUFHSixRQUFRLENBQUNDLGNBQVQsQ0FBd0IsWUFBeEIsQ0FBbkI7QUFDQUcsWUFBWSxDQUFDQyxnQkFBYixDQUE4QixPQUE5QixFQUF1QyxZQUFZO0VBQ2xETixPQUFPLENBQUNPLFNBQVIsQ0FBa0JDLE1BQWxCLENBQXlCLE1BQXpCO0VBQ0FMLFFBQVEsQ0FBQ0ksU0FBVCxDQUFtQkMsTUFBbkIsQ0FBMEIsY0FBMUI7QUFDQSxDQUhELEUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9rb21pa2lhLy4vc3JjL2pzL2J1bmRsZS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJsZXQgbWFpbk5hdiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtb2JpbGVQYW5lbCcpO1xubGV0IHBhZ2Vib2R5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2JvZHknKVswXTtcbmxldCBuYXZCYXJUb2dnbGUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWVudVRvZ2dsZScpO1xubmF2QmFyVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24gKCkge1xuXHRtYWluTmF2LmNsYXNzTGlzdC50b2dnbGUoJ29wZW4nKTtcblx0cGFnZWJvZHkuY2xhc3NMaXN0LnRvZ2dsZSgnbWVudS1pcy1vcGVuJyk7XG59KTsiXSwibmFtZXMiOlsibWFpbk5hdiIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJwYWdlYm9keSIsImdldEVsZW1lbnRzQnlUYWdOYW1lIiwibmF2QmFyVG9nZ2xlIiwiYWRkRXZlbnRMaXN0ZW5lciIsImNsYXNzTGlzdCIsInRvZ2dsZSJdLCJzb3VyY2VSb290IjoiIn0=